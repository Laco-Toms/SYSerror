rootProject.name = "Zdravotný Asistent"
include(":app")
 