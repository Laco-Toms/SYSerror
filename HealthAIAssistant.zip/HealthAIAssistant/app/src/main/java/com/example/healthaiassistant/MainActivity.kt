package com.example.healthaiassistant
import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val radioGroupGender = findViewById(R.id.radioGroupGender) as RadioGroup
        val editTextAge = findViewById<EditText>(R.id.editTextAge)
        val editTextMedications = findViewById<EditText>(R.id.editTextMedications)
        val editTextSymptoms = findViewById<EditText>(R.id.editTextSymptoms)
        val editTextFeeling = findViewById<EditText>(R.id.editTextFeeling)
        val analyzeButton = findViewById<Button>(R.id.analyzeButton)

        analyzeButton.setOnClickListener {
            val selectedGenderId = radioGroupGender.checkedRadioButtonId
            val selectedGender = when (selectedGenderId) {
                R.id.radioMale -> "Male"
                R.id.radioFemale -> "Female"
                else -> "Not selected"
            }
            val age = editTextAge.text.toString()
            val medications = editTextMedications.text.toString()
            val symptoms = editTextSymptoms.text.toString()
            val feeling = editTextFeeling.text.toString()

            val result = analyzeData(selectedGender, age, medications, symptoms, feeling)

            // Spustenie ResultActivity a odovzdanie výsledku
            val intent = Intent(this, ResultActivity::class.java)
            intent.putExtra("ANALYSIS_RESULT", result)
            startActivity(intent)
        }
    }

    fun analyzeData(gender: String, age: String, medications: String, symptoms: String, feeling: String): String {
        var result = "Based on your input:\n"
        result += "Gender: $gender\n"
        result += "Age: $age\n"
        result += "Medications: $medications\n"
        result += "Symptoms: $symptoms\n"
        result += "Feeling: $feeling\n\n"

        if (symptoms.contains("pain") && feeling.contains("bad")) {
            result += "It is recommended to consult a doctor if symptoms persist or worsen."
        } else {
            result += "Monitor your symptoms. If they don't improve, consider consulting a doctor."
        }
        return result
    }
}